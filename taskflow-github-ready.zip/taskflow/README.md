# TaskFlow

Minimal aesthetic task management web app.

## Features
- Add / Edit / Delete tasks
- Priority & category filters
- Dark / Light mode
- LocalStorage persistence
- Notifications & reminders
- Responsive design

## Tech Stack
- HTML
- CSS
- Vanilla JavaScript
